console.log("Background worker started");chrome.runtime.onInstalled.addListener(()=>{console.log("Extension installed.")});
